package modelo;

import java.io.Serializable;

public class Animal implements Comparable<Animal>, Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }

    @Override
    public String toString() {
        return "Animal{" + "id: " + id + ", nombre: " + nombre + ", especie: " + especie + ", alimentacion: " + alimentacion + '}';
    }

    @Override
    public int compareTo(Animal o) {
        return Integer.compare(this.id, o.id);
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }

    public String toCSV() {
        return id + ", " + nombre + ", " + especie + ", " + alimentacion.name();
    }
    
}
