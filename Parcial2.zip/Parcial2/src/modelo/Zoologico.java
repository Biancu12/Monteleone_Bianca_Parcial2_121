package modelo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import modelo.Animal;
import modelo.Animal;
import modelo.TipoAlimentacion;
import modelo.TipoAlimentacion;

public class Zoologico<T> implements Iterable<T>{
    private List<T> items = new LinkedList<>();
    
    public void agregar(T item){
        if (item == null) {
            throw new IllegalArgumentException("Esta lista no almacena nulos");
        }
        items.add(item);
    }
    
    public void eliminar(int indice){
        validarIndice(indice);
        items.remove(indice);
    }
    
    public T obtener(int indice){
        validarIndice(indice);
        return items.get(indice);
    }
    
    public List<T> filtrar(Predicate<? super T> criterio){
        List<T> aux = new LinkedList<>(); 
        for(T item : items){
            if(criterio.test(item)){
                aux.add(item);
            }
        }
        return aux;
    }
            
    private void validarIndice(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("El item no esta en la lista");
        }
    }
    
    @Override
    public Iterator<T> iterator() {
        if (!items.isEmpty() && items.get(0) instanceof Comparable) {
            return iteratorNatural();
        }
        return items.iterator();
    }
    
    private Iterator<T> iteratorNatural() {
        List<T> aux = new ArrayList<>(items);
        aux.sort(null);
        return aux.iterator();
    }
    
    public void ordenar(){
        Iterator<T> iterador = iterator();
        while (iterador.hasNext()){
            System.out.println(iterador.next());
        }
    }
    
    public void ordenar(Comparator<? super T> comparator) {
        List<T> aux = new ArrayList<>(items);
        aux.sort(comparator);
        Iterator<T> it = aux.iterator();
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for(T item : items){
            accion.accept(item);
        }
    }
    
    public void guardarEnArchivo(String path) {
        try (FileOutputStream archivo = new FileOutputStream(path); 
                ObjectOutputStream salida = new ObjectOutputStream(archivo) {
        }) {
            salida.writeObject(items);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static List<Animal> cargarDesdeArchivo(String path) {
        List<Animal> toReturn = new ArrayList<>();
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(path))) {
            toReturn = (List<Animal>) input.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }

    public static void guardarEnCSV(List<? extends Animal> lista,String path) {
        File archivo = new File(path);
        try {
            if (archivo.exists()) {
                System.out.println("El archivo ya existe");
            } else {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Ocurrio un error al crear el archivo");
        }
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
            bw.write("id,nombre,especie,alimentacion\n");
            for (Animal animal : lista) {
                bw.write(animal.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println("Ocurrio un error al crear el archivo");
        }
    }

    public List<Animal> cargarDesdeCSV(String path) {
        List<Animal> toReturn = new ArrayList<>();
        try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            String linea;
            bf.readLine();
            while ((linea = bf.readLine()) != null) {
                if (linea.endsWith("\n")) {
                    linea = linea.substring(linea.length() - 1);
                }
                String[] data = linea.split(", ");
                if (data.length == 4) {
                    int id = Integer.parseInt(data[0]);
                    String nombre = data[1];
                    String especie = data[2];
                    TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
                    Animal e = new Animal(id, nombre, especie, alimentacion);
                    toReturn.add(e);
                }
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("Problema al cargar empleados");
        }
        return toReturn;
    }
    
    public static List<Animal> cargarEmpleadosCSV(String path){
       List<Animal> toReturn = new ArrayList<>();
        try (BufferedReader bf =  new BufferedReader(new FileReader(path))) {
            String linea;
            //si no te lee 1 añado el bf.redlie
            while((linea = bf.readLine()) != null){
               if (linea.endsWith("\n")){
                    linea = linea.substring(linea.length()-1);
               } 
               String[] data = linea.split(",");
               if (data.length == 4){
                int id = Integer.parseInt(data[0]);
                String nombre = data[1];
                String especie = data[2];
                TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3]);
                Animal animal = new Animal(id, nombre, especie, alimentacion);
                toReturn.add(animal);

               }
            }

        } catch (IOException ex) {
            System.out.println("error maestro");
        }

         return toReturn;
    }
}
