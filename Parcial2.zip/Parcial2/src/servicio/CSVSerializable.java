package servicio;

@FunctionalInterface
public interface CSVSerializable<T> {

    void toCSV();
    
}
